
const filterButtons = document.querySelectorAll('.filter-btn');
const rooms = document.querySelectorAll('.room');

filterButtons.forEach(button => {
  button.addEventListener('click', (e) => {
    const filter = e.target.getAttribute('data-filter');
    
    rooms.forEach(room => {
      const status = room.getAttribute('data-status');
      
      if (filter === 'todas') {
        room.style.display = 'block';
      } else if (filter === 'disponibles' && status === 'disponible') {
        room.style.display = 'block';
      } else if (filter === 'ocupadas' && status === 'ocupada') {
        room.style.display = 'block';
      } else {
        room.style.display = 'none';
      }
    });
  });
});

rooms.forEach(room => {
  room.addEventListener('click', () => {
    const statusElement = room.querySelector('.status');
    const currentStatus = statusElement.textContent.trim().toLowerCase();

    if (currentStatus === 'disponible') {
      room.classList.remove('available');
      room.classList.add('occupied');
      statusElement.textContent = 'Ocupada';
      room.setAttribute('data-status', 'ocupada');
    } else if (currentStatus === 'ocupada') {
      room.classList.remove('occupied');
      room.classList.add('available');
      statusElement.textContent = 'Disponible';
      room.setAttribute('data-status', 'disponible');
    }
  });
});
