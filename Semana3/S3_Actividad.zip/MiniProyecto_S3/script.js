
const darkModeButton = document.getElementById("dark-mode-btn");


darkModeButton.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});
